"""
Structured logging and reasoning trace for auditability.
All pipeline decisions are recorded for debugging and evaluation.
"""
from __future__ import annotations
import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import structlog

from config.settings import settings


# ─────────────────────────────────────────────
# Configure structlog
# ─────────────────────────────────────────────

def configure_logging() -> None:
    settings.logs_dir.mkdir(parents=True, exist_ok=True)
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(logging.DEBUG),
        logger_factory=structlog.WriteLoggerFactory(),
    )


def get_logger(name: str) -> structlog.BoundLogger:
    configure_logging()
    return structlog.get_logger(name)


# ─────────────────────────────────────────────
# Reasoning Trace
# ─────────────────────────────────────────────

@dataclass
class StageLog:
    stage: str
    timestamp: float
    details: dict[str, Any]


@dataclass
class ReasoningTrace:
    """
    Captures the full reasoning trace for one question.
    Can be serialized for debugging, evaluation, and auditability.
    """
    question: str
    stages: list[StageLog] = field(default_factory=list)
    retrieval_summary: list[dict] = field(default_factory=list)
    sql_logs: list[dict] = field(default_factory=list)
    start_time: float = field(default_factory=time.perf_counter)
    latency_ms: float = 0.0
    verified: bool = False

    def log_stage(self, stage: str, description: str = "", **kwargs: Any) -> None:
        self.stages.append(StageLog(
            stage=stage,
            timestamp=time.perf_counter() - self.start_time,
            details={"description": description, **kwargs},
        ))

    def log_retrieval(self, evidences: list) -> None:
        self.retrieval_summary = [
            {
                "chunk_id": e.chunk.chunk_id,
                "doc_id": e.chunk.doc_id,
                "page": e.chunk.page,
                "chunk_type": e.chunk.chunk_type.value,
                "rerank_score": round(e.rerank_score, 4),
                "bm25_score": round(e.bm25_score, 4),
                "dense_score": round(e.dense_score, 4),
                "text_preview": e.chunk.text[:120],
            }
            for e in evidences
        ]

    def log_sql(self, query: str, result: str) -> None:
        self.sql_logs.append({"query": query, "result": result})

    def finish(self, latency_ms: float, verified: bool) -> None:
        self.latency_ms = latency_ms
        self.verified = verified

    def summary(self) -> str:
        stage_names = [s.stage for s in self.stages]
        n_evidence = len(self.retrieval_summary)
        n_sql = len(self.sql_logs)
        return (
            f"Stages: {' → '.join(stage_names)} | "
            f"Evidence: {n_evidence} chunks | "
            f"SQL: {n_sql} queries | "
            f"Verified: {self.verified} | "
            f"Latency: {self.latency_ms:.0f}ms"
        )

    def to_dict(self) -> dict:
        return {
            "question": self.question,
            "latency_ms": self.latency_ms,
            "verified": self.verified,
            "stages": [
                {"stage": s.stage, "t": round(s.timestamp, 3), **s.details}
                for s in self.stages
            ],
            "retrieval": self.retrieval_summary,
            "sql": self.sql_logs,
        }

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2)
