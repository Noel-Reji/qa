"""
SQL Reasoning Engine — Table-as-Database
Converts extracted tables into DuckDB relations for deterministic computation.
Drives text-to-SQL for financial QA.
"""
from __future__ import annotations
import re
import json
from typing import Any, Optional

import duckdb
import pandas as pd

from config.models import ParsedDocument, SQLResult, Table
from config.settings import settings
from logging_utils.tracer import get_logger

log = get_logger(__name__)


# ─────────────────────────────────────────────
# Type Coercion
# ─────────────────────────────────────────────

def _try_numeric(val: str) -> Any:
    """Best-effort conversion: strip commas/$ and parse float."""
    cleaned = re.sub(r"[$,%()\s]", "", val.strip())
    cleaned = cleaned.replace("(", "-").replace(")", "")   # accounting negatives
    if cleaned in ("", "-", "N/A", "n/a", "—"):
        return None
    try:
        return float(cleaned)
    except ValueError:
        return val


def _coerce_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Try to cast columns to numeric where possible."""
    for col in df.columns:
        if df[col].dtype == object:
            converted = df[col].apply(lambda v: _try_numeric(str(v)) if pd.notna(v) else None)
            if converted.apply(lambda v: isinstance(v, (int, float)) or v is None).all():
                df[col] = pd.to_numeric(converted, errors="coerce")
    return df


# ─────────────────────────────────────────────
# SQL Engine
# ─────────────────────────────────────────────

class TableSQLEngine:
    """
    Registers all tables from parsed documents into DuckDB.
    Executes text-to-SQL queries deterministically.
    """

    def __init__(self) -> None:
        self.conn = duckdb.connect(settings.sql.db_path)
        self._registered: set[str] = set()
        self._table_registry: dict[str, Table] = {}   # sql_name → Table

    def register_document(self, doc: ParsedDocument) -> None:
        for table in doc.tables:
            self._register_table(table)

    def _register_table(self, table: Table) -> None:
        sql_name = table.sql_table_name
        if sql_name in self._registered:
            return

        if not table.rows or not table.headers:
            return

        df = pd.DataFrame(table.rows, columns=table.headers)
        df = _coerce_dataframe(df)

        try:
            self.conn.register(sql_name, df)
            self._registered.add(sql_name)
            self._table_registry[sql_name] = table
            log.debug("table_registered",
                      table=sql_name,
                      rows=len(df),
                      cols=len(df.columns))
        except Exception as e:
            log.warning("table_register_failed", table=sql_name, error=str(e))

    def execute(self, sql: str) -> SQLResult:
        """Run SQL and return structured result."""
        try:
            result_df = self.conn.execute(sql).df()
            result_df = result_df.head(settings.sql.max_rows_returned)

            # Extract scalar if single value
            raw_value: Any = result_df
            if result_df.shape == (1, 1):
                raw_value = result_df.iloc[0, 0]
            elif result_df.shape[0] == 1:
                raw_value = result_df.iloc[0].to_dict()

            return SQLResult(
                query=sql,
                result_df_json=result_df.to_json(orient="records"),
                raw_value=raw_value,
                success=True,
            )
        except Exception as e:
            log.warning("sql_error", query=sql[:200], error=str(e))
            return SQLResult(
                query=sql,
                result_df_json="[]",
                raw_value=None,
                error=str(e),
                success=False,
            )

    def schema_summary(self) -> str:
        """Return a compact schema string for LLM prompts."""
        lines: list[str] = []
        for sql_name, table in self._table_registry.items():
            col_str = ", ".join(table.headers[:10])
            caption = f" ({table.caption})" if table.caption else ""
            lines.append(
                f"TABLE {sql_name}{caption}: [{col_str}]  "
                f"({len(table.rows)} rows, page {table.page})"
            )
        return "\n".join(lines) or "No tables registered."

    def table_names(self) -> list[str]:
        return list(self._registered)


# ─────────────────────────────────────────────
# Text-to-SQL Planner
# ─────────────────────────────────────────────

TEXT_TO_SQL_PROMPT = """\
You are a SQL expert. Given the database schema and a question, write a DuckDB SQL query.

SCHEMA:
{schema}

QUESTION: {question}

Rules:
- Use only tables and columns from the schema above.
- Prefer aggregations (SUM, AVG, COUNT, MAX, MIN) for numerical questions.
- Cast text columns to FLOAT using TRY_CAST when doing math.
- Return only the SQL query, no explanation.
- If the question cannot be answered with SQL, return: NOT_APPLICABLE
"""


def build_sql_prompt(schema: str, question: str) -> str:
    return TEXT_TO_SQL_PROMPT.format(schema=schema, question=question)


def extract_sql(llm_response: str) -> Optional[str]:
    """Extract SQL from LLM response, stripping markdown fences."""
    # Remove code fences
    cleaned = re.sub(r"```sql\s*", "", llm_response, flags=re.IGNORECASE)
    cleaned = re.sub(r"```", "", cleaned)
    cleaned = cleaned.strip()

    if "NOT_APPLICABLE" in cleaned:
        return None

    # Validate it looks like SQL
    if re.match(r"^\s*(SELECT|WITH|INSERT|UPDATE)", cleaned, re.IGNORECASE):
        return cleaned

    # Try to find SQL block inside prose
    match = re.search(
        r"(SELECT\s.+?)(?:\n\n|$)", cleaned, re.IGNORECASE | re.DOTALL
    )
    if match:
        return match.group(1).strip()

    return None
