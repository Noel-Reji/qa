"""
Ingestion Pipeline — Parse Once, Query Many
Handles PDF, DOCX, scanned PDFs, tables, multi-column layouts.
"""
from __future__ import annotations
import hashlib
import json
import re
import uuid
from pathlib import Path
from typing import Iterator

import pdfplumber
import fitz  # PyMuPDF
from pydantic import BaseModel

from config.models import Chunk, ChunkType, ParsedDocument, Table, DocumentRevision
from config.settings import settings
from logging_utils.tracer import get_logger

log = get_logger(__name__)


# ─────────────────────────────────────────────
# Text Cleaner
# ─────────────────────────────────────────────

def clean_text(text: str) -> str:
    """Normalize whitespace and common OCR artifacts."""
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[^\x20-\x7E\n]", " ", text)   # strip non-ASCII
    text = re.sub(r"\.{3,}", "...", text)
    return text.strip()


# ─────────────────────────────────────────────
# Chunker
# ─────────────────────────────────────────────

def chunk_text(
    text: str,
    chunk_size: int = 512,
    overlap: int = 64,
) -> list[str]:
    """
    Token-approximate sliding window chunking.
    Uses word count as a token proxy (fast, no tokenizer dep).
    """
    words = text.split()
    chunks: list[str] = []
    step = chunk_size - overlap
    for i in range(0, len(words), step):
        chunk = " ".join(words[i : i + chunk_size])
        if chunk.strip():
            chunks.append(chunk)
    return chunks


# ─────────────────────────────────────────────
# Table Extractor
# ─────────────────────────────────────────────

class TableExtractor:
    """Extract tables from a PDF page using pdfplumber."""

    def extract_from_page(
        self, page: pdfplumber.page.Page, doc_id: str, page_num: int
    ) -> list[Table]:
        tables: list[Table] = []
        for raw_table in page.extract_tables():
            if not raw_table or len(raw_table) < 2:
                continue
            headers = [str(h or "").strip() for h in raw_table[0]]
            # Deduplicate headers
            seen: dict[str, int] = {}
            clean_headers: list[str] = []
            for h in headers:
                if h in seen:
                    seen[h] += 1
                    clean_headers.append(f"{h}_{seen[h]}")
                else:
                    seen[h] = 0
                    clean_headers.append(h or f"col_{len(clean_headers)}")

            rows = []
            for raw_row in raw_table[1:]:
                row = [str(cell or "").strip() for cell in raw_row]
                if any(cell for cell in row):   # skip blank rows
                    rows.append(row)

            if not rows:
                continue

            table_id = f"{doc_id}_t{page_num}_{len(tables)}"
            sql_name = re.sub(r"\W+", "_", table_id).lower()
            tables.append(Table(
                table_id=table_id,
                doc_id=doc_id,
                page=page_num,
                caption=None,
                headers=clean_headers,
                rows=rows,
                sql_table_name=sql_name,
            ))
        return tables


# ─────────────────────────────────────────────
# PDF Parser
# ─────────────────────────────────────────────

class PDFParser:
    """
    Two-pass PDF parser:
      Pass 1 (pdfplumber) — tables + structured text blocks
      Pass 2 (PyMuPDF)    — fallback OCR-heavy pages, metadata
    """

    def __init__(self) -> None:
        self.table_extractor = TableExtractor()

    def _doc_id(self, path: Path) -> str:
        h = hashlib.md5(path.read_bytes()).hexdigest()[:12]
        return f"{path.stem}_{h}"

    def parse(self, path: Path) -> ParsedDocument:
        log.info("parsing_pdf", path=str(path))
        doc_id = self._doc_id(path)
        all_chunks: list[Chunk] = []
        all_tables: list[Table] = []

        revision = self._detect_revision(path, doc_id)

        with pdfplumber.open(path) as pdf:
            total_pages = len(pdf.pages)
            for page_num, page in enumerate(pdf.pages, start=1):
                # ── Tables ──────────────────────────────────────
                page_tables = self.table_extractor.extract_from_page(
                    page, doc_id, page_num
                )
                all_tables.extend(page_tables)

                # Mark table regions so we don't double-chunk them
                table_bboxes = [t.metadata.get("bbox") for t in page_tables]

                # ── Text ─────────────────────────────────────────
                raw_text = page.extract_text() or ""
                if not raw_text.strip():
                    # Fallback: PyMuPDF for this page
                    raw_text = self._pymupdf_page_text(path, page_num - 1)

                page_text = clean_text(raw_text)
                if not page_text:
                    continue

                section_path = self._detect_section(page_text)

                for i, chunk_str in enumerate(
                    chunk_text(page_text,
                               settings.retrieval.chunk_size,
                               settings.retrieval.chunk_overlap)
                ):
                    all_chunks.append(Chunk(
                        chunk_id=f"{doc_id}_p{page_num}_c{i}",
                        doc_id=doc_id,
                        page=page_num,
                        chunk_type=ChunkType.TEXT,
                        text=chunk_str,
                        section_path=section_path,
                        revision=revision,
                        metadata={"filename": path.name},
                    ))

                # ── Table → text chunks ──────────────────────────
                for table in page_tables:
                    table_text = self._table_to_text(table)
                    all_chunks.append(Chunk(
                        chunk_id=f"{table.table_id}_chunk",
                        doc_id=doc_id,
                        page=page_num,
                        chunk_type=ChunkType.TABLE,
                        text=table_text,
                        table_id=table.table_id,
                        section_path=section_path,
                        revision=revision,
                        metadata={"filename": path.name},
                    ))

        log.info("parsed_pdf",
                 doc_id=doc_id,
                 pages=total_pages,
                 chunks=len(all_chunks),
                 tables=len(all_tables))

        return ParsedDocument(
            doc_id=doc_id,
            filename=path.name,
            chunks=all_chunks,
            tables=all_tables,
            metadata={"path": str(path)},
            revision=revision,
            total_pages=total_pages,
        )

    def _pymupdf_page_text(self, path: Path, page_idx: int) -> str:
        """Extract text from a single page via PyMuPDF (better for complex layouts)."""
        try:
            with fitz.open(str(path)) as doc:
                page = doc[page_idx]
                return page.get_text("text")
        except Exception as e:
            log.warning("pymupdf_fallback_failed", error=str(e))
            return ""

    def _table_to_text(self, table: Table) -> str:
        """Render table as markdown-style text for embedding."""
        lines = []
        if table.caption:
            lines.append(f"Table: {table.caption}")
        lines.append(" | ".join(table.headers))
        lines.append(" | ".join(["---"] * len(table.headers)))
        for row in table.rows[:settings.retrieval.table_chunk_rows]:
            lines.append(" | ".join(row))
        return "\n".join(lines)

    def _detect_section(self, text: str) -> list[str]:
        """Heuristically detect section headings from text block."""
        lines = text.split("\n")[:5]
        heading_pattern = re.compile(
            r"^(Section\s+\d[\d.]*|Part\s+[IVX\d]+|\d+\.\s+[A-Z]|APPENDIX)",
            re.IGNORECASE,
        )
        return [l.strip() for l in lines if heading_pattern.match(l.strip())]

    def _detect_revision(self, path: Path, doc_id: str) -> DocumentRevision:
        """Detect revision markers from filename or first-page text."""
        name = path.stem.lower()
        version = "v1"
        date = None
        date_match = re.search(r"(\d{4}[-_]\d{2}[-_]\d{2})", name)
        if date_match:
            date = date_match.group(1)
        ver_match = re.search(r"v(\d+[\d.]*)", name)
        if ver_match:
            version = f"v{ver_match.group(1)}"
        return DocumentRevision(
            doc_id=doc_id, version=version, date=date, is_authoritative=True
        )


# ─────────────────────────────────────────────
# Corpus Ingestion Orchestrator
# ─────────────────────────────────────────────

class CorpusIngester:
    """
    Ingests all documents in a directory.
    Yields ParsedDocument objects for downstream indexing.
    """

    def __init__(self) -> None:
        self.pdf_parser = PDFParser()
        self._supported = {".pdf"}

    def ingest_all(self, corpus_dir: Path) -> Iterator[ParsedDocument]:
        paths = sorted(corpus_dir.rglob("*"))
        docs = [p for p in paths if p.suffix.lower() in self._supported]
        log.info("corpus_scan", total_files=len(docs))
        for path in docs:
            try:
                yield self.pdf_parser.parse(path)
            except Exception as e:
                log.error("parse_failed", path=str(path), error=str(e))
