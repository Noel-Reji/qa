"""
Evaluation Harness
Tracks: exact match, semantic similarity, numerical correctness,
citation quality, latency, and token cost across the benchmark.
"""
from __future__ import annotations
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np
from rapidfuzz import fuzz
from rouge_score import rouge_scorer

from config.models import AgentAnswer
from logging_utils.tracer import get_logger

log = get_logger(__name__)


# ─────────────────────────────────────────────
# Metrics
# ─────────────────────────────────────────────

@dataclass
class QuestionResult:
    question_id: str
    question: str
    gold_answer: str
    predicted_answer: str
    exact_match: bool
    fuzzy_score: float          # 0–100 (rapidfuzz token_sort_ratio)
    rouge_l: float              # 0–1
    numerical_match: Optional[bool]  # None if not numerical
    abstained: bool
    confidence: float
    latency_ms: float
    input_tokens: int
    output_tokens: int
    model_used: str
    question_type: str


@dataclass
class EvalSummary:
    n_questions: int = 0
    exact_match_rate: float = 0.0
    fuzzy_match_rate: float = 0.0     # fuzzy_score >= 80
    rouge_l_mean: float = 0.0
    numerical_accuracy: float = 0.0
    abstention_rate: float = 0.0
    avg_latency_ms: float = 0.0
    p95_latency_ms: float = 0.0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    avg_confidence: float = 0.0
    cost_estimate_usd: float = 0.0    # rough estimate


# ─────────────────────────────────────────────
# Scoring Functions
# ─────────────────────────────────────────────

_rouge = rouge_scorer.RougeScorer(["rougeL"], use_stemmer=True)


def _normalize(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[$,%;()\s]", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text


def exact_match(gold: str, pred: str) -> bool:
    return _normalize(gold) == _normalize(pred)


def fuzzy_score(gold: str, pred: str) -> float:
    return fuzz.token_sort_ratio(_normalize(gold), _normalize(pred))


def rouge_l_score(gold: str, pred: str) -> float:
    scores = _rouge.score(gold, pred)
    return scores["rougeL"].fmeasure


def numerical_match(gold: str, pred: str, tolerance: float = 0.01) -> Optional[bool]:
    """
    If both gold and pred contain a number, check if they match within tolerance.
    Returns None if no numerical answer detected.
    """
    def extract_number(text: str) -> Optional[float]:
        text = re.sub(r"[$,%]", "", text)
        matches = re.findall(r"-?\d[\d,]*\.?\d*", text)
        for m in matches:
            try:
                return float(m.replace(",", ""))
            except ValueError:
                continue
        return None

    g_num = extract_number(gold)
    p_num = extract_number(pred)
    if g_num is None or p_num is None:
        return None
    if g_num == 0:
        return abs(p_num) < 0.01
    return abs(g_num - p_num) / abs(g_num) <= tolerance


# ─────────────────────────────────────────────
# Harness
# ─────────────────────────────────────────────

class EvaluationHarness:
    """
    Load a QA benchmark file (JSONL with {id, question, answer} rows),
    run the pipeline on each, and compute aggregate metrics.
    """

    HAIKU_INPUT_COST = 0.25 / 1_000_000    # $ per token
    HAIKU_OUTPUT_COST = 1.25 / 1_000_000
    SONNET_INPUT_COST = 3.00 / 1_000_000
    SONNET_OUTPUT_COST = 15.00 / 1_000_000

    def __init__(self, pipeline) -> None:
        self.pipeline = pipeline
        self.results: list[QuestionResult] = []

    def load_benchmark(self, path: Path) -> list[dict]:
        items = []
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line:
                    items.append(json.loads(line))
        return items

    def run(self, benchmark_path: Path, max_questions: Optional[int] = None) -> EvalSummary:
        items = self.load_benchmark(benchmark_path)
        if max_questions:
            items = items[:max_questions]

        log.info("eval_start", n=len(items))
        self.results = []

        for item in items:
            qid = item.get("id", str(len(self.results)))
            question = item["question"]
            gold = str(item["answer"])

            try:
                agent_answer: AgentAnswer = self.pipeline.answer(question)
                pred = agent_answer.answer
            except Exception as e:
                log.error("pipeline_error", qid=qid, error=str(e))
                pred = ""
                agent_answer = AgentAnswer(
                    question=question, answer="", confidence=0.0,
                    reasoning_summary="ERROR", evidence_chunks=[],
                    latency_ms=0.0, input_tokens=0, output_tokens=0,
                    model_used="", abstained=True,
                )

            result = QuestionResult(
                question_id=qid,
                question=question,
                gold_answer=gold,
                predicted_answer=pred,
                exact_match=exact_match(gold, pred),
                fuzzy_score=fuzzy_score(gold, pred),
                rouge_l=rouge_l_score(gold, pred),
                numerical_match=numerical_match(gold, pred),
                abstained=agent_answer.abstained,
                confidence=agent_answer.confidence,
                latency_ms=agent_answer.latency_ms,
                input_tokens=agent_answer.input_tokens,
                output_tokens=agent_answer.output_tokens,
                model_used=agent_answer.model_used,
                question_type=agent_answer.question_type,
            )
            self.results.append(result)

            log.info("eval_question",
                     qid=qid,
                     em=result.exact_match,
                     fuzzy=round(result.fuzzy_score, 1),
                     latency_ms=round(result.latency_ms, 0))

        return self._compute_summary()

    def _compute_summary(self) -> EvalSummary:
        n = len(self.results)
        if n == 0:
            return EvalSummary()

        latencies = [r.latency_ms for r in self.results]
        num_results = [r for r in self.results if r.numerical_match is not None]

        # Cost estimate
        haiku_results = [r for r in self.results if "haiku" in r.model_used]
        sonnet_results = [r for r in self.results if "sonnet" in r.model_used or "claude-3" in r.model_used]
        cost = sum(
            r.input_tokens * self.HAIKU_INPUT_COST + r.output_tokens * self.HAIKU_OUTPUT_COST
            for r in haiku_results
        ) + sum(
            r.input_tokens * self.SONNET_INPUT_COST + r.output_tokens * self.SONNET_OUTPUT_COST
            for r in sonnet_results
        )

        return EvalSummary(
            n_questions=n,
            exact_match_rate=sum(r.exact_match for r in self.results) / n,
            fuzzy_match_rate=sum(r.fuzzy_score >= 80 for r in self.results) / n,
            rouge_l_mean=np.mean([r.rouge_l for r in self.results]),
            numerical_accuracy=(
                sum(r.numerical_match for r in num_results) / len(num_results)
                if num_results else 0.0
            ),
            abstention_rate=sum(r.abstained for r in self.results) / n,
            avg_latency_ms=np.mean(latencies),
            p95_latency_ms=float(np.percentile(latencies, 95)),
            total_input_tokens=sum(r.input_tokens for r in self.results),
            total_output_tokens=sum(r.output_tokens for r in self.results),
            avg_confidence=np.mean([r.confidence for r in self.results]),
            cost_estimate_usd=cost,
        )

    def save_results(self, out_dir: Path) -> None:
        out_dir.mkdir(parents=True, exist_ok=True)
        with open(out_dir / "results.jsonl", "w") as f:
            for r in self.results:
                f.write(json.dumps(r.__dict__) + "\n")
        log.info("eval_saved", dir=str(out_dir))

    def error_analysis(self, top_n: int = 10) -> list[dict]:
        """Return the worst-performing questions for debugging."""
        sorted_results = sorted(self.results, key=lambda r: r.fuzzy_score)
        return [
            {
                "qid": r.question_id,
                "question": r.question,
                "gold": r.gold_answer,
                "predicted": r.predicted_answer,
                "fuzzy": r.fuzzy_score,
                "abstained": r.abstained,
            }
            for r in sorted_results[:top_n]
        ]
