"""
Multi-Stage Agent Pipeline
Implements the 6-stage reasoning workflow:
  A) Query Understanding
  B) Retrieval Planning
  C) Evidence Validation
  D) Computation (SQL / arithmetic)
  E) Reasoning (LLM synthesis)
  F) Self-Verification

Adaptive depth: cheap FAST path vs expensive DEEP path.
"""
from __future__ import annotations
import json
import time
from dataclasses import dataclass, field
from typing import Any, Optional

import anthropic

from config.models import (
    AgentAnswer, Chunk, ChunkType, QueryAnalysis,
    QuestionType, ReasoningDepth, RetrievedEvidence,
)
from config.settings import settings
from retrieval.hybrid_retriever import HybridRetriever, prefer_authoritative
from sql_engine.table_db import TableSQLEngine, build_sql_prompt, extract_sql
from logging_utils.tracer import get_logger, ReasoningTrace

log = get_logger(__name__)


# ─────────────────────────────────────────────
# LLM Client
# ─────────────────────────────────────────────

def _llm_call(
    prompt: str,
    model: str,
    max_tokens: int = 1024,
    system: str = "You are a precise financial document analyst.",
) -> tuple[str, int, int]:
    """Returns (text, input_tokens, output_tokens)."""
    client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
    response = client.messages.create(
        model=model,
        max_tokens=max_tokens,
        temperature=settings.llm.temperature,
        system=system,
        messages=[{"role": "user", "content": prompt}],
    )
    text = response.content[0].text
    return text, response.usage.input_tokens, response.usage.output_tokens


# ─────────────────────────────────────────────
# Stage A — Query Understanding
# ─────────────────────────────────────────────

CLASSIFY_PROMPT = """\
Classify this question for a financial document QA system.
Return JSON only with these fields:
{{
  "question_type": one of ["numerical","lookup","comparison","temporal","multi_hop","boolean","aggregation"],
  "requires_computation": true|false,
  "temporal_references": [list of year/date strings mentioned],
  "key_entities": [up to 5 key terms/entities to search for],
  "reasoning_depth": one of ["fast","deep","sql"],
  "sub_questions": [list of sub-questions if multi-hop, else empty]
}}

Question: {question}
"""


def stage_a_classify(question: str) -> QueryAnalysis:
    prompt = CLASSIFY_PROMPT.format(question=question)
    try:
        response, _, _ = _llm_call(
            prompt,
            model=settings.llm.fast_model,
            max_tokens=settings.llm.max_tokens_triage,
        )
        data = json.loads(response)
        return QueryAnalysis(
            raw_question=question,
            question_type=QuestionType(data.get("question_type", "lookup")),
            requires_computation=data.get("requires_computation", False),
            temporal_references=data.get("temporal_references", []),
            key_entities=data.get("key_entities", []),
            reasoning_depth=ReasoningDepth(data.get("reasoning_depth", "fast")),
            sub_questions=data.get("sub_questions", []),
        )
    except Exception as e:
        log.warning("classify_failed", error=str(e))
        # Safe fallback
        return QueryAnalysis(
            raw_question=question,
            question_type=QuestionType.LOOKUP,
            requires_computation=False,
            temporal_references=[],
            key_entities=question.split()[:5],
            reasoning_depth=ReasoningDepth.FAST,
        )


# ─────────────────────────────────────────────
# Stage B — Retrieval Planning
# ─────────────────────────────────────────────

def stage_b_retrieve(
    analysis: QueryAnalysis,
    retriever: HybridRetriever,
) -> list[RetrievedEvidence]:
    cfg = settings.retrieval
    top_k = cfg.rerank_top_n

    # Augment query with key entities
    augmented_query = analysis.raw_question
    if analysis.key_entities:
        augmented_query += " " + " ".join(analysis.key_entities)
    if analysis.temporal_references:
        augmented_query += " " + " ".join(analysis.temporal_references)

    table_only = analysis.reasoning_depth == ReasoningDepth.SQL

    evidences = retriever.retrieve(
        query=augmented_query,
        top_k=top_k,
        table_only=table_only,
    )

    # For multi-hop: also retrieve for each sub-question
    if analysis.sub_questions:
        for sq in analysis.sub_questions[:3]:
            sub_ev = retriever.retrieve(query=sq, top_k=3)
            evidences.extend(sub_ev)

    # Revision-aware deduplication
    evidences = prefer_authoritative(evidences)

    # Deduplicate by chunk_id
    seen: set[str] = set()
    deduped: list[RetrievedEvidence] = []
    for ev in evidences:
        if ev.chunk.chunk_id not in seen:
            seen.add(ev.chunk.chunk_id)
            deduped.append(ev)

    return deduped[:top_k * 2]  # keep a generous set for stage C


# ─────────────────────────────────────────────
# Stage C — Evidence Validation
# ─────────────────────────────────────────────

def stage_c_validate(
    evidences: list[RetrievedEvidence],
    question: str,
    top_n: int = 5,
) -> tuple[list[RetrievedEvidence], float]:
    """
    Returns filtered evidences + confidence estimate.
    Confidence is based on rerank score distribution.
    """
    if not evidences:
        return [], 0.0

    # Sort by rerank score
    evidences.sort(key=lambda e: e.rerank_score, reverse=True)
    top = evidences[:top_n]

    # Confidence heuristic: top score vs second score gap
    if len(top) >= 2:
        confidence = min(1.0, top[0].rerank_score / max(top[1].rerank_score, 0.01) / 5.0)
    else:
        confidence = min(1.0, top[0].rerank_score)

    confidence = max(0.0, min(1.0, confidence))
    return top, confidence


# ─────────────────────────────────────────────
# Stage D — Computation
# ─────────────────────────────────────────────

def stage_d_compute(
    analysis: QueryAnalysis,
    sql_engine: TableSQLEngine,
    fast_model: str,
) -> Optional[tuple[str, str]]:
    """
    If numerical/SQL reasoning needed, generate and execute SQL.
    Returns (sql_query, result_str) or None.
    """
    if not settings.enable_sql_reasoning:
        return None
    if analysis.reasoning_depth != ReasoningDepth.SQL and not analysis.requires_computation:
        return None

    schema = sql_engine.schema_summary()
    if not schema.strip() or schema == "No tables registered.":
        return None

    sql_prompt = build_sql_prompt(schema, analysis.raw_question)
    try:
        sql_response, _, _ = _llm_call(
            sql_prompt,
            model=fast_model,
            max_tokens=256,
        )
        sql = extract_sql(sql_response)
        if not sql:
            return None

        result = sql_engine.execute(sql)
        if result.success:
            result_str = str(result.raw_value) if result.raw_value is not None else "No results"
            log.info("sql_computed", sql=sql[:100], result=result_str[:100])
            return sql, result_str
        else:
            log.warning("sql_failed", error=result.error)
            return None
    except Exception as e:
        log.warning("sql_stage_error", error=str(e))
        return None


# ─────────────────────────────────────────────
# Stage E — Reasoning
# ─────────────────────────────────────────────

REASONING_PROMPT = """\
You are a precise financial document analyst. Answer the question using ONLY the provided evidence.

QUESTION: {question}

EVIDENCE:
{evidence_text}

{sql_section}

INSTRUCTIONS:
1. If the evidence contains the answer, provide it concisely.
2. For numerical answers, show the calculation or cite the exact figure.
3. If evidence is insufficient, say: "Insufficient evidence to answer confidently."
4. Keep your answer under 3 sentences unless computation requires more.
5. End with: CONFIDENCE: [HIGH|MEDIUM|LOW]

Answer:
"""


def stage_e_reason(
    analysis: QueryAnalysis,
    evidences: list[RetrievedEvidence],
    sql_result: Optional[tuple[str, str]],
    model: str,
) -> tuple[str, float, int, int]:
    """Returns (answer_text, confidence, input_tokens, output_tokens)."""
    # Build evidence text (budget-aware)
    budget = settings.cost.max_context_tokens
    evidence_lines: list[str] = []
    used_tokens = 0
    for i, ev in enumerate(evidences):
        line = f"[{i+1}] (Page {ev.chunk.page}, score={ev.rerank_score:.2f})\n{ev.chunk.text}"
        token_est = len(line.split()) * 4 // 3
        if used_tokens + token_est > budget:
            break
        evidence_lines.append(line)
        used_tokens += token_est

    evidence_text = "\n\n".join(evidence_lines) if evidence_lines else "No relevant evidence found."

    sql_section = ""
    if sql_result:
        sql_section = f"SQL COMPUTATION:\nQuery: {sql_result[0]}\nResult: {sql_result[1]}\n"

    prompt = REASONING_PROMPT.format(
        question=analysis.raw_question,
        evidence_text=evidence_text,
        sql_section=sql_section,
    )

    response, in_tok, out_tok = _llm_call(prompt, model=model)

    # Parse confidence from response
    conf_map = {"HIGH": 0.9, "MEDIUM": 0.6, "LOW": 0.3}
    confidence = 0.5
    for label, val in conf_map.items():
        if f"CONFIDENCE: {label}" in response:
            confidence = val
            break

    # Strip confidence line from answer
    answer = response.replace("CONFIDENCE: HIGH", "").replace(
        "CONFIDENCE: MEDIUM", "").replace("CONFIDENCE: LOW", "").strip()

    return answer, confidence, in_tok, out_tok


# ─────────────────────────────────────────────
# Stage F — Self-Verification
# ─────────────────────────────────────────────

VERIFY_PROMPT = """\
Review this answer for the given question and evidence.

QUESTION: {question}
ANSWER: {answer}
EVIDENCE SNIPPET: {evidence_snippet}

Is the answer grounded in the evidence? Does it contain any unsupported claims?
Reply with: VERIFIED or UNSUPPORTED
Then one sentence explaining why.
"""


def stage_f_verify(
    question: str,
    answer: str,
    evidences: list[RetrievedEvidence],
    model: str,
) -> bool:
    """Returns True if answer is verified as grounded."""
    if not settings.enable_self_verify:
        return True
    if not evidences:
        return False

    snippet = evidences[0].chunk.text[:400]
    prompt = VERIFY_PROMPT.format(
        question=question, answer=answer[:300], evidence_snippet=snippet
    )
    try:
        response, _, _ = _llm_call(prompt, model=model, max_tokens=128)
        return "VERIFIED" in response
    except Exception:
        return True  # default to passing if verification fails


# ─────────────────────────────────────────────
# Pipeline Orchestrator
# ─────────────────────────────────────────────

class ReasoningPipeline:
    """
    Full 6-stage pipeline. Adaptive: routes to FAST or DEEP path.
    """

    def __init__(
        self,
        retriever: HybridRetriever,
        sql_engine: TableSQLEngine,
    ) -> None:
        self.retriever = retriever
        self.sql_engine = sql_engine

    def answer(self, question: str) -> AgentAnswer:
        t0 = time.perf_counter()
        trace = ReasoningTrace(question=question)

        # ── Stage A ──────────────────────────────────
        trace.log_stage("A_classify", "Classifying question type")
        analysis = stage_a_classify(question)
        trace.log_stage("A_classify_done", question_type=analysis.question_type.value,
                        depth=analysis.reasoning_depth.value)

        # ── Stage B ──────────────────────────────────
        trace.log_stage("B_retrieve", "Running hybrid retrieval")
        evidences = stage_b_retrieve(analysis, self.retriever)
        trace.log_retrieval(evidences)

        # ── Stage C ──────────────────────────────────
        trace.log_stage("C_validate", "Validating evidence")
        validated, confidence = stage_c_validate(evidences, question)

        # Adaptive model routing
        use_strong = (
            confidence < settings.cost.escalation_threshold
            or analysis.reasoning_depth == ReasoningDepth.DEEP
            or analysis.question_type in (QuestionType.MULTI_HOP, QuestionType.AGGREGATION)
        )
        reasoning_model = settings.llm.strong_model if use_strong else settings.llm.fast_model
        trace.log_stage("C_routing", model=reasoning_model, confidence=confidence)

        # ── Stage D ──────────────────────────────────
        sql_result = None
        if analysis.requires_computation or analysis.reasoning_depth == ReasoningDepth.SQL:
            trace.log_stage("D_sql", "Attempting SQL computation")
            sql_result = stage_d_compute(analysis, self.sql_engine, settings.llm.fast_model)
            if sql_result:
                trace.log_sql(sql_result[0], sql_result[1])

        # ── Stage E ──────────────────────────────────
        trace.log_stage("E_reason", "Synthesizing answer")
        answer_text, answer_conf, in_tok, out_tok = stage_e_reason(
            analysis, validated, sql_result, reasoning_model
        )

        # ── Stage F ──────────────────────────────────
        trace.log_stage("F_verify", "Self-verifying grounding")
        verified = stage_f_verify(question, answer_text, validated, settings.llm.fast_model)
        if not verified and not validated:
            answer_text = "Insufficient evidence to answer this question confidently."
            answer_conf = 0.0

        latency_ms = (time.perf_counter() - t0) * 1000
        trace.finish(latency_ms=latency_ms, verified=verified)

        return AgentAnswer(
            question=question,
            answer=answer_text,
            confidence=answer_conf,
            reasoning_summary=trace.summary(),
            evidence_chunks=[e.chunk.chunk_id for e in validated],
            sql_queries=[sql_result[0]] if sql_result else [],
            question_type=analysis.question_type.value,
            reasoning_depth=analysis.reasoning_depth.value,
            latency_ms=latency_ms,
            input_tokens=in_tok,
            output_tokens=out_tok,
            model_used=reasoning_model,
            abstained=(answer_conf == 0.0),
        )
