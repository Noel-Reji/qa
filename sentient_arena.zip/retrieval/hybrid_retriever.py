"""
Hybrid Retrieval — BM25 + Dense Embeddings + Reranking
Parse-once, query-many architecture backed by FAISS + BM25.
"""
from __future__ import annotations
import json
import pickle
from pathlib import Path
from typing import Optional

import faiss
import numpy as np
from rank_bm25 import BM25Okapi
from sentence_transformers import SentenceTransformer, CrossEncoder

from config.models import Chunk, ChunkType, ParsedDocument, RetrievedEvidence
from config.settings import settings
from logging_utils.tracer import get_logger

log = get_logger(__name__)


# ─────────────────────────────────────────────
# Embedding Model (singleton)
# ─────────────────────────────────────────────

_embed_model: Optional[SentenceTransformer] = None
_rerank_model: Optional[CrossEncoder] = None


def get_embed_model() -> SentenceTransformer:
    global _embed_model
    if _embed_model is None:
        log.info("loading_embed_model", model=settings.embedding.model_name)
        _embed_model = SentenceTransformer(
            settings.embedding.model_name,
            device=settings.embedding.device,
        )
    return _embed_model


def get_rerank_model() -> CrossEncoder:
    global _rerank_model
    if _rerank_model is None:
        log.info("loading_rerank_model")
        _rerank_model = CrossEncoder(
            "cross-encoder/ms-marco-MiniLM-L-6-v2",
            device=settings.embedding.device,
        )
    return _rerank_model


# ─────────────────────────────────────────────
# Index
# ─────────────────────────────────────────────

class DocumentIndex:
    """
    Stores all chunks in memory for BM25 + FAISS retrieval.
    Persists to disk so parsing only happens once.
    """

    def __init__(self) -> None:
        self.chunks: list[Chunk] = []
        self.chunk_id_map: dict[str, int] = {}   # chunk_id → list index
        self._faiss_index: Optional[faiss.IndexFlatIP] = None
        self._bm25: Optional[BM25Okapi] = None
        self._dim: int = 0

    # ── Build ────────────────────────────────

    def build(self, documents: list[ParsedDocument]) -> None:
        log.info("building_index", n_docs=len(documents))
        all_chunks: list[Chunk] = []
        for doc in documents:
            all_chunks.extend(doc.chunks)

        self.chunks = all_chunks
        self.chunk_id_map = {c.chunk_id: i for i, c in enumerate(all_chunks)}

        # BM25
        tokenized = [c.text.lower().split() for c in all_chunks]
        self._bm25 = BM25Okapi(tokenized)
        log.info("bm25_built", n_chunks=len(all_chunks))

        # Dense embeddings
        model = get_embed_model()
        texts = [c.text for c in all_chunks]
        log.info("encoding_chunks", n=len(texts))
        embs = model.encode(
            texts,
            batch_size=settings.embedding.batch_size,
            normalize_embeddings=settings.embedding.normalize,
            show_progress_bar=True,
        ).astype(np.float32)

        self._dim = embs.shape[1]
        self._faiss_index = faiss.IndexFlatIP(self._dim)
        self._faiss_index.add(embs)
        log.info("faiss_built", n_vectors=self._faiss_index.ntotal)

    # ── Persist ──────────────────────────────

    def save(self, index_dir: Path) -> None:
        index_dir.mkdir(parents=True, exist_ok=True)
        faiss.write_index(self._faiss_index, str(index_dir / "dense.faiss"))
        with open(index_dir / "bm25.pkl", "wb") as f:
            pickle.dump(self._bm25, f)
        meta = [
            {
                "chunk_id": c.chunk_id,
                "doc_id": c.doc_id,
                "page": c.page,
                "chunk_type": c.chunk_type.value,
                "text": c.text,
                "table_id": c.table_id,
                "section_path": c.section_path,
                "metadata": c.metadata,
            }
            for c in self.chunks
        ]
        with open(index_dir / "chunks.jsonl", "w") as f:
            for row in meta:
                f.write(json.dumps(row) + "\n")
        log.info("index_saved", dir=str(index_dir))

    def load(self, index_dir: Path) -> None:
        self._faiss_index = faiss.read_index(str(index_dir / "dense.faiss"))
        with open(index_dir / "bm25.pkl", "rb") as f:
            self._bm25 = pickle.load(f)
        self.chunks = []
        with open(index_dir / "chunks.jsonl") as f:
            for line in f:
                row = json.loads(line)
                self.chunks.append(Chunk(
                    chunk_id=row["chunk_id"],
                    doc_id=row["doc_id"],
                    page=row["page"],
                    chunk_type=ChunkType(row["chunk_type"]),
                    text=row["text"],
                    table_id=row.get("table_id"),
                    section_path=row.get("section_path", []),
                    metadata=row.get("metadata", {}),
                ))
        self.chunk_id_map = {c.chunk_id: i for i, c in enumerate(self.chunks)}
        log.info("index_loaded", n_chunks=len(self.chunks))


# ─────────────────────────────────────────────
# Hybrid Retriever
# ─────────────────────────────────────────────

class HybridRetriever:
    """
    Stage B — Retrieve candidate evidence:
      1. BM25 keyword search
      2. Dense semantic search
      3. Reciprocal Rank Fusion to merge
      4. Cross-encoder reranking on top-N
    """

    def __init__(self, index: DocumentIndex) -> None:
        self.index = index

    def retrieve(
        self,
        query: str,
        top_k: int = 5,
        chunk_type_filter: Optional[ChunkType] = None,
        doc_id_filter: Optional[list[str]] = None,
        table_only: bool = False,
    ) -> list[RetrievedEvidence]:
        cfg = settings.retrieval
        bm25_k = cfg.bm25_k
        dense_k = cfg.dense_k

        # ── BM25 ──────────────────────────────
        bm25_scores = self.index._bm25.get_scores(query.lower().split())
        bm25_top_idx = np.argsort(bm25_scores)[::-1][:bm25_k]

        # ── Dense ─────────────────────────────
        model = get_embed_model()
        q_emb = model.encode(
            [query],
            normalize_embeddings=settings.embedding.normalize,
        ).astype(np.float32)
        dense_scores_arr, dense_top_idx_arr = self.index._faiss_index.search(q_emb, dense_k)
        dense_top_idx = dense_top_idx_arr[0]
        dense_top_scores = dense_scores_arr[0]

        # ── RRF Fusion ────────────────────────
        rrf_scores: dict[int, float] = {}
        K = 60
        for rank, idx in enumerate(bm25_top_idx):
            rrf_scores[int(idx)] = rrf_scores.get(int(idx), 0) + 1.0 / (K + rank + 1)
        for rank, (idx, score) in enumerate(zip(dense_top_idx, dense_top_scores)):
            rrf_scores[int(idx)] = rrf_scores.get(int(idx), 0) + 1.0 / (K + rank + 1)

        # Build candidates
        candidates: list[RetrievedEvidence] = []
        bm25_norm = float(max(bm25_scores)) if bm25_scores.max() > 0 else 1.0
        dense_score_map = {int(i): float(s) for i, s in zip(dense_top_idx, dense_top_scores)}
        bm25_score_map = {int(i): float(bm25_scores[i]) / bm25_norm for i in bm25_top_idx}

        for idx in sorted(rrf_scores, key=rrf_scores.get, reverse=True)[: (top_k * 3)]:
            chunk = self.index.chunks[idx]

            # Apply filters
            if chunk_type_filter and chunk.chunk_type != chunk_type_filter:
                continue
            if doc_id_filter and chunk.doc_id not in doc_id_filter:
                continue
            if table_only and chunk.chunk_type != ChunkType.TABLE:
                continue

            candidates.append(RetrievedEvidence(
                chunk=chunk,
                bm25_score=bm25_score_map.get(idx, 0.0),
                dense_score=dense_score_map.get(idx, 0.0),
            ))

        if not candidates:
            return []

        # ── Cross-encoder reranking ────────────
        rerank_model = get_rerank_model()
        pairs = [(query, c.chunk.text[:512]) for c in candidates]
        rerank_scores = rerank_model.predict(pairs)
        for ev, score in zip(candidates, rerank_scores):
            ev.rerank_score = float(score)

        candidates.sort(key=lambda e: e.rerank_score, reverse=True)

        # Threshold filter
        threshold = settings.retrieval.similarity_threshold
        result = [e for e in candidates if e.rerank_score > threshold][:top_k]

        log.debug(
            "retrieved",
            query=query[:60],
            n_candidates=len(candidates),
            n_returned=len(result),
        )
        return result


# ─────────────────────────────────────────────
# Revision-Aware Selector
# ─────────────────────────────────────────────

def prefer_authoritative(
    evidences: list[RetrievedEvidence],
) -> list[RetrievedEvidence]:
    """
    If multiple revisions of the same doc exist,
    prefer chunks from the most recent authoritative version.
    """
    # Group by doc base name
    doc_groups: dict[str, list[RetrievedEvidence]] = {}
    for ev in evidences:
        base = ev.chunk.doc_id.rsplit("_", 1)[0]
        doc_groups.setdefault(base, []).append(ev)

    result: list[RetrievedEvidence] = []
    for group in doc_groups.values():
        authoritative = [e for e in group if
                         e.chunk.revision and e.chunk.revision.is_authoritative]
        result.extend(authoritative if authoritative else group)

    result.sort(key=lambda e: e.rerank_score, reverse=True)
    return result
