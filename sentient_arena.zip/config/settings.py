"""
Sentient Arena — Central Configuration
All system tunables in one place for reproducibility.
"""
from __future__ import annotations
import os
from pathlib import Path
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings


class EmbeddingConfig(BaseModel):
    model_name: str = "BAAI/bge-small-en-v1.5"   # fast, local, good quality
    batch_size: int = 128
    device: str = "cpu"                            # swap to "cuda" if available
    normalize: bool = True


class RetrievalConfig(BaseModel):
    bm25_k: int = 10              # BM25 candidates
    dense_k: int = 10             # Dense candidates
    rerank_top_n: int = 5         # After reranking
    chunk_size: int = 512         # tokens per chunk
    chunk_overlap: int = 64
    table_chunk_rows: int = 50    # rows per table chunk
    similarity_threshold: float = 0.35


class LLMConfig(BaseModel):
    provider: str = "anthropic"                      # anthropic | openai | openrouter
    strong_model: str = "claude-sonnet-4-20250514"   # deep reasoning
    fast_model: str = "claude-haiku-4-5-20251001"    # cheap triage / classification
    max_tokens_reasoning: int = 1024
    max_tokens_triage: int = 256
    temperature: float = 0.0       # deterministic for QA
    cache_seed: int = 42


class SQLConfig(BaseModel):
    engine: str = "duckdb"        # duckdb | sqlite | pandas
    db_path: str = ":memory:"
    max_rows_returned: int = 500
    timeout_seconds: int = 10


class CostConfig(BaseModel):
    """Token budget guardrails."""
    max_context_tokens: int = 8000     # context fed to LLM per question
    escalation_threshold: float = 0.6  # confidence below which we escalate to strong model
    cache_enabled: bool = True
    cache_dir: str = ".cache/sentient"


class Settings(BaseSettings):
    # Sub-configs
    embedding: EmbeddingConfig = Field(default_factory=EmbeddingConfig)
    retrieval: RetrievalConfig = Field(default_factory=RetrievalConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)
    sql: SQLConfig = Field(default_factory=SQLConfig)
    cost: CostConfig = Field(default_factory=CostConfig)

    # Paths
    corpus_dir: Path = Path("data/corpus")
    index_dir: Path = Path("data/index")
    logs_dir: Path = Path("logs")
    eval_dir: Path = Path("data/eval")

    # API Keys (from env)
    anthropic_api_key: str = Field(default="", env="ANTHROPIC_API_KEY")
    openai_api_key: str = Field(default="", env="OPENAI_API_KEY")
    openrouter_api_key: str = Field(default="", env="OPENROUTER_API_KEY")

    # Feature flags
    enable_sql_reasoning: bool = True
    enable_multi_agent: bool = True
    enable_self_verify: bool = True
    enable_revision_tracking: bool = True

    class Config:
        env_file = ".env"
        env_nested_delimiter = "__"


settings = Settings()
