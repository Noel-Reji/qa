"""
Shared domain models for the Sentient Arena pipeline.
Using dataclasses + Pydantic for clarity and validation.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional
from pydantic import BaseModel


# ─────────────────────────────────────────────
# Enums
# ─────────────────────────────────────────────

class QuestionType(str, Enum):
    NUMERICAL       = "numerical"       # requires arithmetic
    LOOKUP          = "lookup"          # direct fact retrieval
    COMPARISON      = "comparison"      # compare two values
    TEMPORAL        = "temporal"        # time-based reasoning
    MULTI_HOP       = "multi_hop"       # chains of evidence
    BOOLEAN         = "boolean"         # yes/no
    AGGREGATION     = "aggregation"     # sum/avg/count over table


class ReasoningDepth(str, Enum):
    FAST    = "fast"     # single retrieval + haiku
    DEEP    = "deep"     # multi-step + sonnet
    SQL     = "sql"      # table → DuckDB → answer


class ChunkType(str, Enum):
    TEXT    = "text"
    TABLE   = "table"
    HEADER  = "header"
    FIGURE  = "figure"


# ─────────────────────────────────────────────
# Document Structures
# ─────────────────────────────────────────────

@dataclass
class DocumentRevision:
    doc_id: str
    version: str
    date: Optional[str]
    is_authoritative: bool = True


@dataclass
class Chunk:
    chunk_id: str
    doc_id: str
    page: int
    chunk_type: ChunkType
    text: str                        # raw text representation
    metadata: dict[str, Any] = field(default_factory=dict)
    table_id: Optional[str] = None   # if this chunk is a table
    embedding: Optional[list[float]] = None
    revision: Optional[DocumentRevision] = None
    section_path: list[str] = field(default_factory=list)  # e.g. ["Section 3", "3.2 Revenue"]

    @property
    def token_estimate(self) -> int:
        return len(self.text.split()) * 4 // 3  # rough approximation


@dataclass
class Table:
    table_id: str
    doc_id: str
    page: int
    caption: Optional[str]
    headers: list[str]
    rows: list[list[Any]]
    sql_table_name: str   # name used in DuckDB
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ParsedDocument:
    doc_id: str
    filename: str
    chunks: list[Chunk]
    tables: list[Table]
    metadata: dict[str, Any]
    revision: Optional[DocumentRevision] = None
    total_pages: int = 0


# ─────────────────────────────────────────────
# Query / Answer Structures
# ─────────────────────────────────────────────

@dataclass
class QueryAnalysis:
    raw_question: str
    question_type: QuestionType
    requires_computation: bool
    temporal_references: list[str]
    key_entities: list[str]
    reasoning_depth: ReasoningDepth
    sub_questions: list[str] = field(default_factory=list)


@dataclass
class RetrievedEvidence:
    chunk: Chunk
    bm25_score: float = 0.0
    dense_score: float = 0.0
    rerank_score: float = 0.0

    @property
    def final_score(self) -> float:
        return self.rerank_score or (0.5 * self.bm25_score + 0.5 * self.dense_score)


@dataclass
class SQLResult:
    query: str
    result_df_json: str     # JSON-serialized DataFrame
    raw_value: Any          # scalar or list
    error: Optional[str] = None
    success: bool = True


class AgentAnswer(BaseModel):
    question: str
    answer: str
    confidence: float               # 0–1
    reasoning_summary: str
    evidence_chunks: list[str]      # chunk_ids
    sql_queries: list[str] = []
    question_type: str = ""
    reasoning_depth: str = ""
    latency_ms: float = 0.0
    input_tokens: int = 0
    output_tokens: int = 0
    model_used: str = ""
    abstained: bool = False         # True if not enough evidence
